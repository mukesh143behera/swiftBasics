//
//  ViewController.swift
//  SwiftBasics
//
//  Created by Mukesh Behera on 14/06/20.
//  Copyright © 2020 Mukesh Behera. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        swift()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func swift()
    {
        
     
        
        //let(unmutable) and var(mutable) declaration
        
        let str = "Hello, playground"
        var str1:String
        
        str1 = "in mukesh"
        
        print(str)
        //str = "hjhj"
        //print(str)
        print(str1)
        
        
        
        
        //Empty string declaration
        
        var sd = ""
        if sd .isEmpty
        {
            print("empty")
            
        }
        else
        {
            print("not empty")
        }
        
        
        
        
        //String comparision
        
        var wer = "hello"
        var wer1 = "hello1"
        
        if wer == wer1
        {
            print("equal")
        }
        else{
            print("not equal")
        }
        
        
        
        
        //print variables values through variable name
        
        var bnm : String
        var ghj : Int
        
        bnm = "mahesh"
        ghj = 40
        
        print(bnm)
        print(ghj)
        
        let yu = bnm + " is " + String(ghj) + " years old "
        print(yu)
        print("\(bnm) is \(ghj) years old")
        
        
        
        
        //Optional
        
        //to makes the variables,datatypes nil, the optional(?) is use
        var nm:String?
        var jm:String?
        
        print(nm) //print nil
        
        nm = "asas"
        
        print(nm)
        
        
        
        
        //Force unrapping
        
        //to unrapp the optional value unrapping(!) is use
        let ty:String?
        let uz:String?
    
        ty = "asas"
        uz = "wewe"
        
        if ty == "asas"
        {
            print("\(ty!)")
        }
        else if uz == "wewe"
        {
            print("\(uz!)")
        }
        else
        {
            print("unknown")
        }
        
        
        
        
        //Arrays declaration
        
        var arr = [Int]() //Empty array declaratoion //Alloc array
        arr = [101,102,103]
        print(type(of: arr))
        print(arr)
        print(arr[1])
        
        
        var arrr1: [String] = ["sas","qwqw","wewe","erer"]
        print(arrr1)
        print(arrr1[2])
        
        
        
        
        //Dictionary
        
        var dic = ["mukesh": 30, "rakesh": 40]
        print(type(of: dic))
        print(dic["mukesh"]!)
        
        if let dicages = dic["rakesh"]
        {
            print("Rakesh is \(dicages) years old")
        }
        
        
        
        
        //Set
        
        var fghy : Set<String> = ["jhbh","hbkj","yuyu","dfdf"]
        print(type(of: fghy))
        
        fghy.insert("mnmn")
        fghy.remove("yuyu")
        print(fghy)
        
        print(fghy.contains("dfdf"))
        print(fghy.contains("jhbh"))
        
        
        
        
        //Tuples
        
        //in tuple multilple value elements are assign to a single variable and
        //in tuple there are multiple variables are assign multiple elements at a time
        
        let tuplevar = ("jhbh","hbkj","yuyu","dfdf")
        print(tuplevar.1)
        
        let (first, last) = ("mukesh", "behera")
        print(first)
        
        let (f1, _) = ("sdsd","wdwd")  //with "_" we can ignore the variable In tuple
        print(f1)
        
        
        
        
        //Control Flow
        
        var num  = 27
        
        if num > 20
        {
            print("num is greater than 20")
        }
        else if num < 20
        {
            print("num is lesser than 20")
        }
        else
        {
            print("unknown")
        }
        
        
        
        
        //Switch
        
        var mhj = "mukesh"
        
        switch mhj {
            
        case "alok":
            print("this is alok")
            
        case "mukesh":
            print("this is mukesh")
        
        default:
            print("unknown person")
        }
        
        
        
        //Loops and Collection
        
        let names = ["sas","qwqw","wewe","erer"]
        
        for name in names {  //For in loop
            
            print(name)
        }
        
        //
        
        for i in 1...10 {
            if i % 2 == 0{
                print(i)

            }
            
        }
        
        //
        
        let two = stride(from: 2, to: 11, by: 2)
        
        for twos in two {
            print(twos)
        }
        
        
        
        
        //Indices
        
        let name2 = ["sas","qwqw","wewe","erer"]
        
        for nameIndex in name2.indices {
            if (nameIndex < 3)
            {
                print(name2[nameIndex])
            }
        }
        
        
        
        
        
        //enumerated
        
        let name3 = ["sas","qwqw","wewe","erer"]
        
        for (index, name) in name3.enumerated() {
            print("\(index): \(name)")
        }
    }


}

